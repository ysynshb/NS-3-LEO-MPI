# epidemic-routing
Experimental epidemic-routing module for ns-3
